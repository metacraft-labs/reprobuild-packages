TEMPLATE = subdirs

SUBDIRS += sensors
