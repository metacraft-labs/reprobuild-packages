TEMPLATE      = subdirs
SUBDIRS       = textfinder
