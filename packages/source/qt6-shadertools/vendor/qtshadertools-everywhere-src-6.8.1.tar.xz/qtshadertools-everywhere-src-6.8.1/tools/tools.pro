TEMPLATE = subdirs
SUBDIRS += qsb
