# KConfig

Persistent platform-independent application settings.

## Introduction

KConfig provides an advanced configuration system. It is made of two parts:
KConfigCore and KConfigGui.

KConfigCore provides access to the configuration files themselves. It features:

- Code generation: describe your configuration in an XML file, and use
  kconfig_compiler to generate classes that read and write configuration
  entries.
- Cascading configuration files (global settings overridden by local settings).
- Optional shell expansion support (see [docs/options.md](@ref options)).
- The ability to lock down configuration options (see
  [docs/options.md](@ref options)).

KConfigGui provides a way to hook widgets to the configuration so that they are
automatically initialized from the configuration and automatically propagate
their changes to their respective configuration files.

