TEMPLATE = subdirs
SUBDIRS = codecs