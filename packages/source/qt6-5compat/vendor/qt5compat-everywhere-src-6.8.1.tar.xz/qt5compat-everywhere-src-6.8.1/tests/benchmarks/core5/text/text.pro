TEMPLATE = subdirs
SUBDIRS = qregexp
