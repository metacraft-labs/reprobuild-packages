TEMPLATE = subdirs
SUBDIRS = qtextcodec
