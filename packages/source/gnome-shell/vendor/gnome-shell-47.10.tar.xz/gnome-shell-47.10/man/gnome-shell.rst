===========
gnome-shell
===========

-------------------------------------
Graphical shell for the GNOME desktop
-------------------------------------

:Manual section: 1
:Manual group: User Commands

SYNOPSIS
--------
**gnome-shell** [*OPTION*...]

DESCRIPTION
-----------
GNOME shell provides core user interface functions for the GNOME 3 desktop,
like switching to windows and launching applications. GNOME shell takes
advantage of the capabilities of modern graphics hardware and introduces
innovative user interface concepts to provide a visually attractive and
easy to use experience.

gnome-shell is a required component of the GNOME desktop, i.e. it is listed in
the RequiredComponents field of /usr/share/gnome-session/sessions/gnome.session.
It is started in the window manager phase of the session.

OPTIONS
-------
``--wayland``

  Run as a wayland compositor

``--display-server``

  Run as a full display server, rather than nested

``--nested``

  Run as a nested compositor

``--no-x11``

  Run wayland compositor without starting Xwayland

``--x11``

  Run with X11 backend

``--wayland-display``\ =\ *DISPLAY*

  Wayland display name to use

``-d``, ``--display``\ =\ *DISPLAY*

  X display to use

``-r``, ``--replace``

  Replace the running window manager

``--sm-disable``

  Disable connection to the session manager

``--sm-client-id``\ =\ *ID*

  Specify session management *ID*

``--sm-save-file``\ =\ *FILE*

  Initialize session from *FILE*

``--sync``

  Make X calls synchronous

``--mode=MODE``

  Use a specific mode, e.g. "gdm" for login screen

``--list-modes``

  List possible modes and exit

``--version``

  Print version and exit

``--help``

  Display help and exit

FILES
-----
/usr/share/gnome-session/sessions/gnome.session,
/usr/share/applications/org.gnome.Shell.desktop.

BUGS
----
The bug tracker can be reached by visiting the website
https://gitlab.gnome.org/GNOME/gnome-shell/issues.
Before sending a bug report, please verify that you have the latest version
of gnome-shell. Many bugs (major and minor) are fixed at each release, and
if yours is out of date, the problem may already have been solved.

ADDITIONAL INFORMATION
----------------------
For further information, visit the website https://gitlab.gnome.org/GNOME/gnome-shell/-/blob/main/README.md.
