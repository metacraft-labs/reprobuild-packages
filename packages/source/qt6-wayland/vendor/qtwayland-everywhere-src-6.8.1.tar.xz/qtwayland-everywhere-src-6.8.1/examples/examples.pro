TEMPLATE = subdirs
SUBDIRS += wayland
